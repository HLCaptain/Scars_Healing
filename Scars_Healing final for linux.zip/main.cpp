#include <iostream>
#include <fstream>

#include "gtest_lite.h"
#include "memtrace.h"
#include "test.h"
#include "IniGame.h"

//#define MEMTRACE

#define TESTING

/// Well, here we go...
int main() {
	GTINIT(std::cin); // Needed for JPorta
#ifdef TESTING
	//iniTest();
	test();
#endif
	

	GTEND(std::cerr); // Needed for JPorta

	return 0;
}