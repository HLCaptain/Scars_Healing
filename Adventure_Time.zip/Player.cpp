#include "Player.h"
#include "String.h"
#include <math.h>
#include "Enemy.h"

//Constructor
Player::Player(const char* Name, double HP, double MaxHP, double BaseDMG, double BaseDEF, size_t Gold, Storage StorageType) : Entity(Name, HP, MaxHP, BaseDMG, BaseDEF), Gold(Gold), StorageType(StorageType) { }

//Default Constructor
Player::Player(double HP, double MaxHP, double BaseDMG, double BaseDEF, size_t Gold) : Entity(HP, MaxHP, BaseDMG, BaseDEF), Gold(Gold) { }

//Destructor
Player::~Player() { }

//Gets the Player's info
std::ostream& Player::getInfoEntity(std::ostream& os, const InfoPreset& Preset) {
	if (Preset.Name)
		os << getName() << std::endl;
	if (Preset.HP)
		os << "\tPlayer HP: " << getHP() << "/" << getMaxHP() << std::endl;
	if (Preset.BaseDEF)
		os << "\tBase Defense: " << getBaseDEF() << std::endl;
	if (Preset.BaseDMG)
		os << "\tPlayer Base Damage: " << getBaseDMG() << std::endl;
	if (Preset.Gold)
		os << "\tPlayer Gold: " << getGold() << std::endl;
	if (Preset.Storage)
		os << "\tPlayer Storage: " << getStorageType().getName() << std::endl;
	if (Preset.Items) {
		os << "\tPlayer Items:" << std::endl << std::endl;
		getStorageType().getInfoItemsAll(os);
	}
	return os;
}

//Gets Player's amount of Gold
size_t Player::getGold() { return Gold; }

//Gets Player's type of Storage
Storage& Player::getStorageType() { return StorageType; }

//Attack an enemy
void Player::attackEnemy(Enemy& e) {
	std::cout << getName() << " HP: " << getHP() << " --> ";
	double EnemyAttackDMG = e.getBaseDMG() - tanh((getBaseDEF()) / (100)) * e.getBaseDMG();
	setHP(getHP() - EnemyAttackDMG);
	std::cout << "HP: " << getHP() << " (" << EnemyAttackDMG * (-1) << " HP)" << std::endl;


	double PlayerAttackDMG = getBaseDMG() - tanh(e.getBaseDEF() / (100)) * getBaseDMG();
	std::cout << e.getName() << " HP: " << e.getHP() << " --> ";
	e.setHP(e.getHP() - PlayerAttackDMG);
	std::cout << e.getHP() << " (" << PlayerAttackDMG * (-1) << " HP by Hand" << std::endl;
}

//Attack an enemy with a weapon
void Player::attackEnemy(Enemy& e, Item& WS) {
	//Base Equations, DONT DELETE

	/*e.setHP(e.getHP() - ((getBaseDMG() + WS.getBonusDMG()) * WS.getBonusDMGM()) + tanh(e.getBaseDEF() / (100)) * ((getBaseDMG() + WS.getBonusDMG()) * WS.getBonusDMGM()));
	setHP(getHP() - e.getBaseDMG() + tanh(((getBaseDEF() + WS.getBonusDEF()) * WS.getBonusDEFM()) / (100)) * e.getBaseDMG());
	std::cout << getName() << " HP: " << getHP() << std::endl;
	std::cout << e.getName() << " HP: " << e.getHP() << std::endl;
	*/
	//Formatted Equtions
	//std::cout << getName() << " HP: " << getHP() << " --> ";
	//double EnemyAttackDMG = e.getBaseDMG() + tanh(((getBaseDEF() + WS.getBonusDEF()) * WS.getBonusDEFM()) / (100)) * e.getBaseDMG();
	//setHP(getHP() - EnemyAttackDMG);
	//std::cout << getHP() << " (" << EnemyAttackDMG*(-1) << " HP)" << std::endl;
	//
	//double PlayerAttackDMG = ((getBaseDMG() + WS.getBonusDMG()) * WS.getBonusDMGM()) + tanh(e.getBaseDEF() / (100)) * ((getBaseDMG() + WS.getBonusDMG()) * WS.getBonusDMGM());
	//std::cout << e.getName() << " HP: " << e.getHP() << " --> ";
	//e.setHP(e.getHP() - PlayerAttackDMG);
	//std::cout << e.getHP() << " (" << PlayerAttackDMG * (-1) << " HP by " << WS.getName() << ")" << std::endl;
	
	std::cout << getName() << " HP: " << getHP() << " --> ";
	double PlayerOldHP = getHP();
	double PlayerNewHP = (getHP() - e.getBaseDMG() + tanh(((getBaseDEF() + WS.getBonusDEF()) * WS.getBonusDEFM()) / (100)) * e.getBaseDMG());
	setHP(PlayerNewHP);
	std::cout << getHP() << " (" << PlayerNewHP - PlayerOldHP << " HP)" << std::endl;

	std::cout << e.getName() << " HP: " << e.getHP() << " --> ";
	double EnemyOldHP = e.getHP();
	double EnemyNewHP = (e.getHP() - ((getBaseDMG() + WS.getBonusDMG()) * WS.getBonusDMGM()) + tanh(e.getBaseDEF() / (100)) * ((getBaseDMG() + WS.getBonusDMG()) * WS.getBonusDMGM()));
	e.setHP(EnemyNewHP);
	std::cout << e.getHP() << " (" << EnemyNewHP - EnemyOldHP << " HP by " << WS.getName() << ")" << std::endl;
	
}
