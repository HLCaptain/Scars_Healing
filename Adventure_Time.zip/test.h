#ifndef TEST_H
#define TEST_H

#include "Item.h"

///Basic Constructing tests
void test();

///Initiates everything, then deletes it xd
void iniTest();

///Tests if iniWS worked properly
void iniWSTest(Item* WSItems, const size_t& n);

#endif // TEST_H
