#include <iostream>
#include <fstream>

#include "test.h"
#include "Player.h"
#include "Enemy.h"
#include "IniGame.h"
#include "Actions.h"
#include "Storage.h"

///Basic Constructing tests
void test() {
	std::cout << "test begin" << std::endl;
	Storage Test("Test", "Test Desc", 10, 0);
	Storage World("World", "World", 20, 0);
	//String PName, EName;
	//std::cout << "Player Name: " << std::endl;
	//std::cin >> PName;
	//std::cout << "Enemy Name: " << std::endl;
	//std::cin >> EName;
	Player HLCaptain("HLCaptain", 200, 200, 5, 5, 0, Test);
	Enemy E1("Mastermind", 100000, 99, 50, 50);
	//Player HLCaptain(PName.getStr(), 200, 200, 5, 5, 0, Test);
	//Enemy E1(EName.getStr(), 100000, 99, 50, 50);
	HLCaptain.getInfoEntity(); //writing out info of player
	E1.getInfoEntity(); //writing out info of enemy
	HLCaptain.getStorageType().getInfo(); //writing out info of bakpak
	HLCaptain.attackEnemy(E1); //attacking e1
	HLCaptain.getInfoEntity(); //writing out info of player, hp changed
	E1.getInfoEntity(); //writing out info of enemy, hp changed

	//Testing abs
	Entity* p = &HLCaptain;
	p->getInfoEntity();

	//Adding a weapon
	size_t n = iniWSNumber();

	//ONLY TEST
	n = 1;
	Item WS(ItemType::WeaponShield, "Sword Of Blaise", "This epic sword lets you change the world, but you have to let it guide your way.", 50, 1.2, 20, 1.2);
	Item* WSItems = &WS;
	//ONLY TEST

	//Item* WSItems = iniWS();
	iniWSTest(WSItems, n);
	for (size_t i = 0; i < n; i++) {
		World.addItem(WSItems[i]);
		HLCaptain.getStorageType().addItem(WSItems[i]);
	}
	//actionSeq(HLCaptain, &E1, 1);

	//ONLY TEST
	for (size_t i = 0; i < 3; i++) {
		HLCaptain.attackEnemy(E1, WS);
	}
	//ONLY TEST
}

///Tests if iniWS worked properly
void iniWSTest(Item* WSItems, const size_t& n) {
	for (size_t i = 0; i < n; i++)
	{
		WSItems[i].getInfoItems();
	}
}

///Initiates everything, then deletes it xd
void iniTest() {
	//Initialization test on Weapons/Shield Items
	const size_t n = iniWSNumber();
	Item* WSItems = iniWS();
	iniWSTest(WSItems, n);
	delete[] WSItems;
}