#ifndef INFOPRESET_H
#define INFOPRESET_H


class InfoPreset {
public:
	bool Name;
	bool HP;
	bool BaseDMG;
	bool BaseDEF;
	bool DisplayNum;
	bool Attack;
	bool Gold;
	bool Storage;
	bool Items;
	size_t Num;

	///Constructor
	InfoPreset(bool Name = true, bool HP = true, bool BaseDMG = true, bool BaseDEF = true, bool DisplayNum = false, bool Attack = false, bool Gold = true, bool Storage = true, bool Items = true, const size_t& cNum = 0) : Name(Name), HP(HP), BaseDMG(BaseDMG), BaseDEF(BaseDEF), DisplayNum(DisplayNum), Attack(Attack), Gold(Gold), Storage(Storage), Items(Items), Num(cNum) { }

	///Destructor
	virtual ~InfoPreset() { }

};

#endif //INFOPRESET_H