#ifndef INIGAME_H
#define INIGAME_H

#include "Item.h"

///Getting the Number of WeaponShields in the file
size_t iniWSNumber(const char* WSPath = "WeaponShield.txt");

///Initializing WeaponShield Items from a file
Item* iniWS(const char* WSPath = "WeaponShield.txt");

#endif //INIGAME_H
