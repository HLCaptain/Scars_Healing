#ifndef ITEM_H
#define ITEM_H

#include "String.h"
#include "InfoPreset.h"

///Types of Items
enum class ItemType {WeaponShield, Potion, Vanity};

class Item {
protected:
	///Type of the Item
	ItemType Type;

	///Name of the Item
	String Name;

	///Description of the Item
	String Desc;

	///Additive Bonus Damage of Item
	double BonusDMG;

	///Multiplied Bonus Damage of Item
	double BonusDMGM;

	///Additive Bonus Defense of Item
	double BonusDEF;

	///Multiplied Bonus Defense of Item
	double BonusDEFM;
public:
	///Default Constructor
	Item(const ItemType& Type = ItemType::WeaponShield);

	///Constructor
	Item(const ItemType& Type, const char* Name = "DisItem", const char* Desc = "This is an Item.", const double& BonusDMG = 0, const double& BonusDMGM = 1, const double& BonusDEF = 0, const double& BonusDEFM = 1);

	///Destructor
	virtual ~Item();

	///Writes out the Item's info to an output
	virtual std::ostream& getInfoItems(std::ostream& os = std::cout, const InfoPreset& Preset = InfoPreset());

	///Gets Name
	const char* getName();

	///Gets Description
	const char* getDesc();

	///Gets Additive Bonus Damage of Item
	double getBonusDMG();

	///Gets Multiplied Bonus Damage of Item
	double getBonusDMGM();

	///Gets Additive Bonus Defense of Item
	double getBonusDEF();

	///Gets Multiplied Bonus Defense of Item
	double getBonusDEFM();

	///Assign
	//Item& operator=(Item& rhs_s);
};

#endif //ITEM_H

