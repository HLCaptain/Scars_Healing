#ifndef ENTITY_H
#define ENTITY_H

#include "String.h"
#include "InfoPreset.h"


class Entity {
	///Entity Name
	String Name;

	///Healthpoint of the entity
	double HP;

	///Maximum Healthpoint of the entity
	double MaxHP;

	///Base Damage of the entity
	double BaseDMG;

	///Base Defense of the entity
	double BaseDEF;
public:
	///Constructor
	Entity(const char* Name, double HP = 100, double MaxHP = 100, double BaseDMG = 5, double BaseDEF = 5);

	///Default Constructor
	Entity(double HP = 100, double MaxHP = 100, double BaseDMG = 5, double BaseDEF = 5);

	///Destructor
	virtual ~Entity();

	///Gets Entity's name
	const char* getName();

	///Gets Entity's Base Damage
	double getBaseDMG();

	///Gets Entity's Base Defense
	double getBaseDEF();

	///Gets Entity's HP
	double getHP();

	///Gets Entity's MaxHP
	double getMaxHP();

	///Sets Entity's HP
	void setHP(const double hp);

	///Displays the info of an entity, dynamically controlable with zeros and ones
	virtual std::ostream& getInfoEntity(std::ostream& os = std::cout, const InfoPreset& Preset = InfoPreset()) = 0;
};

#endif //ENTITY_H

