#include <iostream>
#include <fstream>

#include "memtrace.h"
#include "test.h"
#include "IniGame.h"

///Well, here we go...
int main() {
	iniTest();
	test();

	return 0;
}