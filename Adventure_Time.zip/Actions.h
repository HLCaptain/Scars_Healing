#ifndef ACTIONS_H
#define ACTIONS_H

#include "Item.h"
#include "Player.h"
#include "Enemy.h"

///States
enum class ActionEnums { DecidePhase, WeaponSelection, EnemySelection, ItemSelection, PlayerDead, Quit, EnemiesDead };

///Deletes an element from an Array
template<typename T>
void deleteElement(T* Array, size_t& ArraySize, size_t Index);

///Gets the number of the Item, the Player has chosen
size_t getItemNum(Player& PLYR, ActionEnums& ActionState);

///Player Chooses an enemy to attack, Enemy and Player can die
ActionEnums attackSeq(Player& PLYR, Enemy* Enemies, size_t EnemyNum, Item& CWS);

///Decide the Action you want to make
ActionEnums decideSeq(Player& PLYR, const size_t& EnemyNum);

///Statemachine of an Action
void actionSeq(Player& PLYR, Enemy* Enemies, size_t EnemyNum);

#endif //ACTIONS_H

