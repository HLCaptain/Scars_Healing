#include "Storage.h"

static InfoPreset AttackWithItem(0, 0, 0, 0, 0, 1); //stopped defining, because we need the only the attack to be 1
static InfoPreset AllInfoItem(1, 0, 1, 1, 0, 0, 1, 1, 1); //all info of the item, except attacking
//static InfoPreset AllInfo(1, 0, 1, 1, 0, 0, 0, 1, 1); //all info of the item, except attacking

///Default Constructor
Storage::Storage(const char* Name, const char* Desc, size_t Size, size_t NumberOfItems) : Name(Name), Desc(Desc), Size(Size), NumberOfItems(NumberOfItems), Items(new Item[Size]) { }

///Copy Constructor
Storage::Storage(const Storage& S) : Name(S.Name), Desc(S.Desc), Size(S.Size), NumberOfItems(S.NumberOfItems), Items(new Item[S.Size]) {
	for (size_t i = 0; i < Size; i++)
		Items[i] = S.Items[i];
}

///Destructor
Storage::~Storage() {
	delete[] Items;
	//std::cout << "Storage dtor" << std::endl;
}

///Writes out the Storage's info to the console
void Storage::getInfo() {
	std::cout << "Storage Name: " << Name << std::endl;
	std::cout << "Storage Description: " << Desc << std::endl;
	std::cout << "Number Of Items: " << NumberOfItems << std::endl;
	std::cout << "Storage Size: " << Size << std::endl;
	//std::cout << "Item Selected: " << Selected << std::endl;
}

///Writes out the Item's infos in the storage to the console
std::ostream& Storage::getInfoItemsAll(std::ostream& os) {
	for (size_t i = 0; i < NumberOfItems; i++) {
		std::cout << i + 1 << ". ";
		Items[i].getInfoItems(std::cout, AllInfoItem);
	}
	return os;
}

///Writes out the Item's infos in the storage to the console
void Storage::getInfoItemsUse() {
	for (size_t i = 0; i < NumberOfItems; i++) {
		std::cout << i + 1 << ". ";
		Items[i].getInfoItems(std::cout, AttackWithItem);
	}
}

///Writes out the Item's name to the console
void Storage::getItemName() {
	std::cout << "Names of the Items in " << Name << std::endl;
}

///Gets name
const char* Storage::getName() { return Name.getStr(); }

///Gets description
const char* Storage::getDescription() { return Desc.getStr(); }

///Gets size of storage
size_t Storage::getSize() { return Size; }

/*
bool Storage::getItem(size_t& SelectedItem, Item& ChosenItem) {
	if (SelectedItem < NumberOfItems) {
		ChosenItem = Items[SelectedItem];
		return true;
	}
	else {
		if (NumberOfItems == 0)
			std::cout << "No items in the inventory :(" << std::endl;
		else
			std::cout << "Couldnt find item in place :(" << std::endl;
		return false;
	}
}*/

///Gets the NUMBER OF ITEMS, TRIVIAL YOU FUCK, STOP NAMING THINGS THAT ARE TRIVIAL
size_t Storage::getNumberOfItems() { return NumberOfItems; }

///Sets size of storage
void Storage::setSize(const size_t& SizeC) { Size = SizeC; }

///Sets the NUMBER OF ITEMS, TRIVIAL YOU FUCK, STOP NAMING THINGS THAT ARE TRIVIAL
void Storage::setNumberOfItems(const size_t& NumberOfItemsC) { NumberOfItems = NumberOfItemsC; }

///Gets an Item in the storage
Item Storage::getItem(size_t& ItemIndex) const {
	return Items[ItemIndex];
}

void Storage::addItem(Item& NewItem) {///////////////////////////////////////////////////////////////////////////////////////////////Static
	if (NumberOfItems >= Size) { std::cout << "Storage is FULL" << std::endl; } //checks if storage is full or not
	else {
		Items[NumberOfItems] = NewItem;  
		NumberOfItems++; //number of items grew
		std::cout << Items[NumberOfItems-1].getName() << " has been added to " << getName() << std::endl;
	}
}

///Removes an item from the Storage
void Storage::removeItem(size_t& RemoveIndex) {
	NumberOfItems--;
	for (size_t i = RemoveIndex; i < NumberOfItems; i++) {
		Items[i] = Items[i + 1];
	}
}









///Adds an Item to the Storage if it is not full, dynamicly stored
/*void Storage::addItem(WeaponShield WS) {///////////////////////////////////////////////////////////////////////////////////////////////DO IT
	if (NumberOfItems >= Size) { std::cout << "Storage is FULL" << std::endl; } //checks if storage is full or not
	else {
		setNumberOfItems(getNumberOfItems() + 1); //number of items grew
		setNumberOfWS(getNumberOfWS() + 1); //number of Weapons or Shields grew
		WeaponShield* NewPointer = new WeaponShield[NumberOfItems]; //dynamic allocation of memory
		for (size_t i = 0; i < NumberOfItems - 1; i++) { //copying old data
			NewPointer[i] = WeaponShields[i];
		}
		delete[] WeaponShields; //deleting old data
		NewPointer[NumberOfItems - 1] = WS; //additional data written
		WeaponShields = NewPointer; //pointer to new data
	}
}*/