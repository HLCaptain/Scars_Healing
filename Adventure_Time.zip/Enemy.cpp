#include "Enemy.h"
#include "Player.h"
#include <math.h>

//Constructor
Enemy::Enemy(const char* Name, double HP, double MaxHP, double BaseDMG, double BaseDEF) : Entity(Name, HP, MaxHP, BaseDMG, BaseDEF)
{
	std::cout << "Enemy ctor" << std::endl;
}

//Default Constructor
Enemy::Enemy(double HP, double MaxHP, double BaseDMG, double BaseDEF) : Entity("Mike Cook", HP, MaxHP, BaseDMG, BaseDEF)
{
	//std::cout << "Enemy ctor" << std::endl;
	//getInfo();
}

//Destructor
Enemy::~Enemy() {
	//std::cout << "Enemy dtor" << std::endl;
}
/*
//Writes out the Enemy's info to the console
void Enemy::getInfo() {
	std::cout << "Enemy Name: " << Name << std::endl;
	std::cout << "Enemy HP: " << HP << std::endl;
	std::cout << "Enemy Base Damage: " << BaseDMG << std::endl;
	std::cout << "Enemy Base Defense: " << BaseDEF << std::endl << std::endl;
}

//Gets Enemy's name
const char* Enemy::getName() { return Name.getStr(); }

//Gets Enemy's Base Damage
double Enemy::getBaseDMG() { return BaseDMG; }

//Gets Enemy's Base Defense
double Enemy::getBaseDEF() { return BaseDEF; }

//Gets Enemy's HP
double Enemy::getHP() { return HP; }

//Gets Enemy's MaxHP
double Enemy::getMaxHP() { return MaxHP; }

//Sets Enemy's HP
void Enemy::setHP(const double hp) { HP = hp; }
*/

//Attack Player without taking Damage from it
void Enemy::attackPlayer(Player& PLYR, Item& WS) {
	std::cout << PLYR.getName() << " HP: " << PLYR.getHP() << " --> ";
	double EnemyAttackDMG = getBaseDMG() - tanh(((PLYR.getBaseDEF() + WS.getBonusDEF()) * WS.getBonusDEFM()) / (100)) * getBaseDMG();
	PLYR.setHP(getHP() - EnemyAttackDMG);
	std::cout << PLYR.getHP() << " (" << EnemyAttackDMG * (-1) << " HP caused by " << getName() << ")" << std::endl;
}

///Displays the info of an enemy, dynamically controlable with zeros and ones
std::ostream& Enemy::getInfoEntity(std::ostream& os, const InfoPreset& Preset) {
	if (Preset.DisplayNum)
		os << Preset.Num + 1 << ". ";
	if (Preset.Attack)
		os << "Attack ";
	if (Preset.Name)
		os << getName() << std::endl;
	if (Preset.HP)
		os << "\tHP: " << getHP() << "/" << getMaxHP() << std::endl;
	if (Preset.BaseDEF)
		os << "\tBase Defense: " << getBaseDEF() << std::endl;
	if (Preset.BaseDMG)
		os << "\tBase Damage: " << getBaseDMG() << std::endl;
	return os;
}
