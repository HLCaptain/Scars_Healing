#include "IniGame.h"
#include "Item.h"
#include <fstream>
#include <iostream>

///Getting the Number of WeaponShields in the file
size_t iniWSNumber(const char* WSPath) {
	std::ifstream WSFile;
	WSFile.open(WSPath);
	if (WSFile.good()) {
		while (!WSFile.eof()) {
			size_t NumberOfItems;
			WSFile >> NumberOfItems;
			WSFile.close();
			return NumberOfItems;
		}
	}
	else {
		std::cout << "Unable to load the Weapon/Shield Items" << std::endl;
	}
	WSFile.close();
	return 0;
}

///Initializing WeaponShield Items from a file
Item* iniWS(const char* WSPath) {
	std::ifstream WSFile;
	WSFile.open(WSPath);
	if (WSFile.good()) {
		size_t NumberOfItems;
		WSFile >> NumberOfItems;
		Item* WSItems = new Item[NumberOfItems];
		//Additive Bonus Damage of Sword or Shield
		double WBonusDMG;

		//Multiplied Bonus Damage of Sword or Shield
		double WBonusDMGM;

		//Additive Bonus Defense of Sword or Shield
		double WBonusDEF;

		//Multiplied Bonus Defense of Sword or Shield
		double WBonusDEFM;

		//Name of the Item
		char* WName = new char[256];

		//Description of the Item
		char* WDesc  = new char[256];

		for (size_t i = 0; i < NumberOfItems; i++) {
			WSFile.ignore();

			//Reading WName
			//ItemsFile >> WName;
			WSFile.getline(WName, 256);

			//Reading WDesc
			//ItemsFile >> WDesc;
			WSFile.getline(WDesc, 256);

			//Reading WBonusDMG
			WSFile.ignore(1);
			WSFile >> WBonusDMG;

			//Reading WBonusDMGM
			WSFile >> WBonusDMGM;

			//Reading WBonusDEF
			WSFile >> WBonusDEF;

			//Reading WBonusDEFM
			WSFile >> WBonusDEFM;

			//Construct WeaponShield
			Item WS(ItemType::WeaponShield, WName, WDesc, WBonusDMG, WBonusDMGM, WBonusDEF, WBonusDEFM);
			WSItems[i] = WS; //Copying WeaponShield
			std::cout << WName << " loaded in." << std::endl; //TEST
		}
		delete[] WName;
		delete[] WDesc;
		WSFile.close();
		std::cout << std::endl;
		return WSItems;
	}
	else {
		std::cout << "Unable to load the Weapon/Shield Items" << std::endl;
	}
	WSFile.close();
	return NULL;
}