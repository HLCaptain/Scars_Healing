#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>
#include "String.h"
#include "Storage.h"
#include "Enemy.h"
#include "Entity.h"
#include "InfoPreset.h"

class Player : public Entity {
	/*
	///Healthpoint of the player
	double HP;

	///Maximum Healthpoint of the player
	double MaxHP;

	///Base Damage of the player
	double BaseDMG;

	///Base Defense of the player
	double BaseDEF;

	///Player Name
	String Name;
	*/

	///Amount of Gold
	size_t Gold;

	///Storage
	Storage StorageType;
public:
	///Constructor
	Player(const char* Name, double HP = 100, double MaxHP = 100, double BaseDMG = 5, double BaseDEF = 5, size_t Gold = 0, Storage StorageType = Storage());
	
	///Default Constructor
	Player(double HP = 100, double MaxHP = 100, double BaseDMG = 5, double BaseDEF = 5, size_t Gold = 0);

	///Destructor
	virtual ~Player();

	///Writes out the Player's info to the console
	std::ostream& getInfoEntity(std::ostream& os = std::cout, const InfoPreset & Preset = InfoPreset());
	//std::ostream& getInfoEntity(std::ostream& os = std::cout, bool name = true, bool hp = true, bool def = true, bool dmg = true, bool gold = true, bool storage = true, bool items = true, const size_t& Num = 0);

	/*
	///Gets Player's name
	const char* getName();

	///Gets Player's Base Damage
	double getBaseDMG();

	///Gets Player's Base Defense
	double getBaseDEF();

	///Gets Player's HP
	double getHP();

	///Gets Player's MaxHP
	double getMaxHP();

	///Sets Player's HP
	void setHP(const double hp);
	*/

	///Gets Player's amount of Gold
	size_t getGold();

	///Gets Player's type of Storage
	Storage& getStorageType();

	///Attack an enemy
	void attackEnemy(Enemy& e);
	

	///Attack an enemy with a weapon
	void attackEnemy(Enemy& e, Item& WS);

};

#endif //PLAYER_H
