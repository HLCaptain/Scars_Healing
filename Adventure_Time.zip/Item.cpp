#include "Item.h"

///Default Constructor
Item::Item(const ItemType& Type) : Type(Type), Name("DisItem"), Desc("This is an Item."), BonusDMG(0), BonusDMGM(1), BonusDEF(0), BonusDEFM(1) {}

///Constructor
Item::Item(const ItemType& Type, const char* Name, const char* Desc, const double& BonusDMG, const double& BonusDMGM, const double& BonusDEF, const double& BonusDEFM) : Type(Type), Name(Name), Desc(Desc), BonusDMG(BonusDMG), BonusDMGM(BonusDMGM), BonusDEF(BonusDEF), BonusDEFM(BonusDEFM) {}

///Destructor
Item::~Item() { }

///Gets name
const char* Item::getName() { return Name.getStr(); }

//Gets description
const char* Item::getDesc() { return Desc.getStr(); }

//Gets Additive Bonus Damage of Item
double Item::getBonusDMG() { return BonusDMG; }

//Gets Multiplied Bonus Damage of Item
double Item::getBonusDMGM() { return BonusDMGM; }

//Gets Additive Bonus Defense of Item
double Item::getBonusDEF() { return BonusDEF; }

//Gets Multiplied Bonus Defense of Item
double Item::getBonusDEFM() { return BonusDEFM; }

/*
///Assign
Item& Item::operator=(Item& rhs) {
	Name = rhs.getName();
	Desc = rhs.getDesc();
	BonusDMG = rhs.getBonusDMG();
	BonusDMGM = rhs.getBonusDMGM();
	BonusDEF = rhs.getBonusDEF();
	BonusDEFM = rhs.getBonusDEFM();
	return *this;
}*/

///Writes out the Item's info to an output
std::ostream& Item::getInfoItems(std::ostream& os, const InfoPreset& Preset) {
	if (Type == ItemType::WeaponShield) {
		if (Preset.Attack)
			os << "Attack with " << getName() << std::endl;
		else
		{
			if (Preset.Name) {
				os << "Weapon/Shield Name: " << getName() << std::endl;
				os << "Weapon/Shield Description: " << getDesc() << std::endl;
			}
			if (Preset.BaseDMG) {
				std::cout << "Weapon/Shield Bonus Damage: " << getBonusDMG() << std::endl;
				std::cout << "Weapon/Shield Bonus Damage Multiplier: " << getBonusDMGM() << std::endl;
			}
			if (Preset.BaseDEF) {
				std::cout << "Weapon/Shield Bonus Defense: " << getBonusDEF() << std::endl;
				std::cout << "Weapon/Shield Bonus Defense Multiplier: " << getBonusDEFM() << std::endl << std::endl;
			}
		}
	}
	return os;
}
