#ifndef STORAGE_H
#define STORAGE_H

#include "String.h"
#include "Item.h"

class Storage {
public:
	///Name of the Storage
	String Name;

	///Description of the Storage
	String Desc;

	///Size of Storage, how many items it can hold
	size_t Size;

	///Number of Items, self explanitory
	size_t NumberOfItems;

	//Items in the storage
	Item* Items;
public:
	///Default Constructor
	Storage(const char* Name = "BakPak", const char* Desc = "This is a BakPak.", size_t Size = 5, size_t NumberOfItems = 0);

	///Copy Constructor
	Storage(const Storage& S);

	///Destructor
	virtual ~Storage();

	///Writes out the Storage's info to the console
	void getInfo();

	///Writes out the Item's infos in the storage to the console
	std::ostream& getInfoItemsAll(std::ostream& os);

	///Writes out the Item's infos in the storage to the console
	virtual void getInfoItemsUse();

	///Writes out the Item's name to the console
	virtual void getItemName();

	///Gets name
	const char* getName();

	///Gets description
	const char* getDescription();

	///Gets size of storage
	size_t getSize();

	///Gets an Item in the storage
	Item getItem(size_t& ItemIndex) const;

	//template<typename T>
	///Gets an item in the storage
	//bool getItem(size_t& SelectedItem, Item& WS);

	//Gets the NUMBER OF ITEMS, TRIVIAL YOU FUCK, STOP NAMING THINGS THAT ARE TRIVIAL
	///Gets the number of Items
	size_t getNumberOfItems();

	///Sets size of storage
	void setSize(const size_t& SizeC);

	///Sets the NUMBER OF ITEMS, TRIVIAL YOU FUCK, STOP NAMING THINGS THAT ARE TRIVIAL
	void setNumberOfItems(const size_t& NumberOfItemsC);

	///Adds an Item to the Storage if it is not full, staticly stored
	void addItem(Item& NewItem);

	///Removes an item from the Storage
	void removeItem(size_t& RemoveNum);

};

#endif //STORAGE_H

