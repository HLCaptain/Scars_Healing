#include "Actions.h"
#include <typeinfo>
#include "Item.h"
#include "Enemy.h"
#include "Player.h"

static InfoPreset EnemyAttackBasic(1, 0, 0, 0, 1, 1, 0, 0, 0, 0);
static InfoPreset EnemyAttack(1, 1, 1, 1, 1, 1, 0, 0, 0, 0);

///Deletes an element from an Array
template<typename T>
void deleteElement(T* Array, size_t& ArraySize, size_t Index) {
	if (ArraySize < 2) {
		ArraySize = 0;
		Array = NULL;
	}
	else {
		T* NewArray = new T[ArraySize - 1];
		for (size_t i = 0; i < Index; i++) {
			NewArray[i] = Array[i];
		}
		for (size_t i = Index + 1; i < ArraySize; i++) {
			NewArray[i - 1] = Array[i];
		}
		ArraySize--;
		delete[] Array;
		Array = NewArray;
	}
}

///Gets the number of the Item, the Player has chosen
size_t getItemNum(Player& PLYR, ActionEnums& ActionState) {
	size_t ChosenItem = 0;
	if (PLYR.getStorageType().getNumberOfItems() == 0) {
		std::cout << "No items in inventory :(" << std::endl;
		ActionState = ActionEnums::DecidePhase;
		return 0;
	}
	while (ChosenItem > PLYR.getStorageType().getNumberOfItems() || ChosenItem <= 0) {
		PLYR.getStorageType().getInfoItemsUse();
		std::cout << PLYR.getStorageType().getNumberOfItems() + 1 << ". Back" << std::endl;
		std::cout << "Enter 42 to QUIT" << std::endl;
		std::cin >> ChosenItem;
		if (ChosenItem == 42) {
			ActionState = ActionEnums::Quit;
			return 0;
		}
			
		if (ChosenItem > PLYR.getStorageType().getNumberOfItems() + 1 || ChosenItem <= 0) { std::cout << "Select a right Item" << std::endl; break; }
		if (ChosenItem == PLYR.getStorageType().getNumberOfItems() + 1) {
			ActionState = ActionEnums::DecidePhase;
			return 0;
		}
	}
	ActionState = ActionEnums::EnemySelection;
	return ChosenItem; //the not index value because of the 0 check
}

///Player Chooses an enemy to attack, Enemy and Player can die
ActionEnums attackSeq(Player& PLYR, Enemy* Enemies, size_t EnemyNum, Item& CWS) {
	size_t ChosenEnemy = 0;
	while (ChosenEnemy > EnemyNum || ChosenEnemy <= 0) {
		//Input
		for (size_t i = 0; i < EnemyNum; i++) {
			EnemyAttackBasic.Num = i;
			Enemies[i].getInfoEntity(std::cout, EnemyAttackBasic);
		}
			//Enemies[i].getInfoEntity(std::cout, 1, 0, 0, 0, 1, 1, 1, i);
		std::cout << EnemyNum + 1 << ". Back" << std::endl;
		std::cout << "Enter 42 to QUIT" << std::endl;
		std::cin >> ChosenEnemy;

		//Processing Input
		if (ChosenEnemy == 42)
			return ActionEnums::Quit;
		if (ChosenEnemy == EnemyNum + 1)
			return ActionEnums::WeaponSelection;
		Enemy& CEnemy = Enemies[ChosenEnemy - 1];
		if (ChosenEnemy > 0 && ChosenEnemy <= EnemyNum) {
			PLYR.attackEnemy(CEnemy, CWS);
			for (size_t i = 0; i < EnemyNum; i++) {
				if (i != ChosenEnemy - 1)
					Enemies[i].attackPlayer(PLYR, CWS);
			}
			if (PLYR.getHP() <= 0) {
				std::cout << PLYR.getName() << " died by the final swing of " << CEnemy.getName() << std::endl;
				return ActionEnums::PlayerDead;
			}
			if (CEnemy.getHP() <= 0) {
				std::cout << PLYR.getName() << " Slayed " << CEnemy.getName() << std::endl;
				deleteElement(Enemies, EnemyNum, ChosenEnemy);
			}
			if (EnemyNum == 0) {
				std::cout << PLYR.getName() << " just completed the Demo!" << std::endl;
				return ActionEnums::Quit;
			}
		}
		else
			std::cout << PLYR.getName() << " did not attack... Choose a correct Opponent!" << std::endl;
	}
	return ActionEnums::EnemySelection;
}

///Decide the Action you want to make
ActionEnums decideSeq(Player& PLYR, const size_t& EnemyNum) {
	size_t num = 0;
	size_t UseItem = 0;
	size_t AttackE = 0;
	size_t Info = 0;
	
	if (EnemyNum) {
		AttackE = ++num;
		std::cout << num << ". Attack an Enemy!" << std::endl;
	}
	if (PLYR.getStorageType().getNumberOfItems()) {
		UseItem = ++num;
		std::cout << num << ". Use an Item!" << std::endl;
	}
	Info = ++num;
	std::cout << num << ". Get the Info of EVERYTHING!" << std::endl;
	if (!num) {
		std::cout << "Nothing to Do! Enjoy Real life :)" << std::endl;
		return ActionEnums::Quit;
	}
	std::cout << "Enter 42 to QUIT" << std::endl;

	size_t Choice = 0;
	std::cin >> Choice;
	
	//choices
	if (Choice) {
		if (Choice == 42)
			return ActionEnums::Quit;
		if (AttackE == Choice)
			return ActionEnums::WeaponSelection;
		if (UseItem == Choice)
			return ActionEnums::ItemSelection;
		if (Info == Choice) {
			InfoPreset AllInfoItem(1, 0, 1, 1, 0, 0, 1, 1, 1);
			PLYR.getInfoEntity(std::cout, AllInfoItem);
			return ActionEnums::DecidePhase;
		}
			
	}
	std::cout << "Please choose a valid action!" << std::endl;
	return ActionEnums::DecidePhase;
}

///Statemachine of an Action
void actionSeq(Player& PLYR, Enemy* Enemies, size_t EnemyNum) {
	//Initializing Default Values
	Item DefaultWS;
	//Potion DefaultPotion;

	

	ActionEnums ActionState = ActionEnums::DecidePhase; //CHANGE TO DECIDEPHASE LATER ON

	//Getting action
	std::cout << "What do You do?" << std::endl;
	for (size_t i = 0; i < EnemyNum; i++) {
		EnemyAttack.Num = i;
		Enemies[i].getInfoEntity(std::cout, EnemyAttack);
	}


	Item CWS; //NOT PERMANENT, IT IS AN ITEM

	bool EndAction = false;
	while (!EndAction) {
		switch (ActionState) {
			case ActionEnums::DecidePhase: {
				ActionState = decideSeq(PLYR, EnemyNum);
				break;
			}
			case ActionEnums::WeaponSelection: {
				size_t ChosenItem = getItemNum(PLYR, ActionState);
				if (ActionState == ActionEnums::DecidePhase || ActionState == ActionEnums::Quit) {
					break;
				}
				CWS = PLYR.getStorageType().getItem(--ChosenItem); //ChosenItem -1 because of the indexing
				if (typeid(PLYR.getStorageType().getItem(ChosenItem)) == typeid(DefaultWS))
					ActionState = ActionEnums::EnemySelection;
				break;
			}
			case ActionEnums::EnemySelection: {
				ActionState = attackSeq(PLYR, Enemies, EnemyNum, CWS);
				break;
			}
			case ActionEnums::ItemSelection: {
				std::cout << "USING AN ITEM IS NOT AN OPTION YET YOU DEFENSIVE RETARD" << std::endl;
				ActionState = ActionEnums::DecidePhase;
				break;
			}
			case ActionEnums::PlayerDead: {
				std::cout << "RIP BRUH" << std::endl;
				EndAction = true;
				break;
			}
			case ActionEnums::Quit: {
				std::cout << "Quitting, Hope you enjoyed the Demo!" << std::endl;
				EndAction = true;
				break;
			}
			case ActionEnums::EnemiesDead: {
				std::cout << "Well, nothing to do Here!" << std::endl;
				EndAction = true;
				break;
			}
		}
	}
}

//TEST THE STATE MACHINE TO MAKE IT WORK PROPERLY
