#ifndef ENEMY_H
#define ENEMY_H

#include <iostream>
#include "String.h"
#include "Storage.h"
#include "Entity.h"
#include "InfoPreset.h"

class Player;
class Enemy : public Entity {
	/*
	///Healthpoint of the enemy
	double HP;

	///Maximum Healthpoint of the enemy
	double MaxHP;

	///Base Damage of the enemy
	double BaseDMG;

	///Base Defense of the enemy
	double BaseDEF;

	///Enemy Name
	String Name;
	*/
public:
	///Constructor
	Enemy(const char* Name, double HP = 100, double MaxHP = 100, double BaseDMG = 5, double BaseDEF = 5);

	///Default Constructor
	Enemy(double HP = 100, double MaxHP = 100, double BaseDMG = 5, double BaseDEF = 5);

	///Destructor
	virtual ~Enemy();

	/*
	///Writes out the Enemy's info to the console
	void getInfo();

	///Gets Enemy's name
	const char* getName();

	///Gets Enemy's Base Damage
	double getBaseDMG();

	///Gets Enemy's Base Defense
	double getBaseDEF();

	///Gets Enemy's HP
	double getHP();

	///Gets Enemy's MaxHP
	double getMaxHP();

	///Sets Enemy's HP
	void setHP(const double hp);
	*/

	///Attack Player without taking Damage from it
	void attackPlayer(Player& PLYR, Item& WS);

	///Displays the info of an enemy, dynamically controlable with zeros and ones
	std::ostream& getInfoEntity(std::ostream& os = std::cout, const InfoPreset& Preset = InfoPreset());
	//std::ostream& getInfoEntity(std::ostream& os = std::cout, bool name = true, bool hp = true, bool def = true, bool dmg = true, bool gold = true, bool storage = true, bool items = true, const size_t& Num = 0);
};

#endif //ENEMY_H
