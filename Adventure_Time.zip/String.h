#ifndef STRING_H
#define STRING_H

#include <iostream>

class String
{
	///Data Pointer
	char* pData;

	///Length of the string
	size_t len;
public:
	///Copy Constructor
	String(String const& str);

	///Constructor from string
	String(const char* str = "");

	///Default Constructor from string
	String(const char c);
	
	///Destructor
	virtual ~String() { delete[] pData; }

	///Return the content of the String
	const char* getStr() { return pData; }

	///Return the length of the String
	const size_t getSize() { return len; }

	///Assign from String
	String& operator=(const String& rhs_s);

	///Assign from char*
	String& operator=(const char* rhs_s);

	///Adding String to the original
	String& operator+=(const String& rhs_s) {
		*this = *this + rhs_s;
		return *this;
	}

	///Adding String to the original (returns constant)
	String operator+(const String& rhs_s) const;

	///Adding String to the original (returns constant)
	String operator+(char rhs_c) const { return *this + String(rhs_c); }

};

///Writes out String to outputstream
std::ostream& operator<<(std::ostream& os, String& str);

///Reads in String from inputstream
std::istream& operator>>(std::istream& is, String& s0);

#endif //STRING_H